Here is the replacement files for libvfw32.a I recommend that you
delete that file. 

The files:

libvfw_avi32.a  -- import library for avifil32.dll
libvfw_cap32.a	-- import library for avicap32.dll
libvfw_ms32.a	-- import library for msvfw32.dll

vfw_avi32.def	-- def file for libvfw_avi32.a
vfw_cap32.def	-- def file for libvfw_cap32.a
vfw_ms32.def	-- def file for libvfw_ms32.a

The import libraries can be recreated from the def files with dlltool.
