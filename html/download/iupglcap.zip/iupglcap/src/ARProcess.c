/* Image Processing and Recognition Module for the IUPGLCAP application. */

#ifdef WIN32            
#include <windows.h>    /* necessary because of the Microsoft OpenGL headers dependency */
#endif

#include <GL/gl.h>

#include <stdio.h>
#include <stdlib.h>

#include <im.h>
#include <im_image.h>
#include <im_convert.h>
#include <im_process.h>

#include "ARProcess.h"


void ConvertGLData2Luminance(unsigned char* gl_data, imImage* image)
{
  int i;
  unsigned char* im_data = (unsigned char*)image->data[0];
  for (i = 0; i < image->count; i++)
  {
    *im_data++ = (unsigned char)( 0.2999*(*gl_data) + 0.587*(*(gl_data+1)) + 0.114*(*(gl_data+2)) );
    gl_data += 3;
  }
}


/* converts 0-1 to 0-255 for OpenGL display. */
static void FixGray(imImage* image)
{
  int i;
  unsigned char* im_data = (unsigned char*)image->data[0];
  for (i = 0; i < image->count; i++)
  {
    if (*im_data)
      *im_data = 255;
    im_data++;
  }
}
                     
/* called when the image is allocated, or reallocated when size is changed.
 */
void arReset(imImage* image, int *flags, double value1, double value2)
{
}

/* Process the image 
 * gl_data - right image in OpenGL format
 * image - left image ( in gray scale - IM_GRAY);
 * user_flags[3] - three interface flags;
 * user_value1, user_value2 - real values controled by the user valuators [0,1].
 */
void arProcess(unsigned char* gl_data, imImage *image, int *flags, double value1, double value2)
{
  if (flags[0])
  {
//    ConvertGLData2Luminance(app_data->gl_data, app_data->image);


//    FixGray(image);
  }
}

/* repaint called after each image is drawn on the respective canvas
 */
void arRepaint(int left, int *flags, double value1, double value2)
{
}

/* release internal module memory
 */
void arRelease(void)
{
}

