require"imlua"

local impal = im.PaletteHotIron()
print(impal)
print(im.ColorDecode(impal[1]))

